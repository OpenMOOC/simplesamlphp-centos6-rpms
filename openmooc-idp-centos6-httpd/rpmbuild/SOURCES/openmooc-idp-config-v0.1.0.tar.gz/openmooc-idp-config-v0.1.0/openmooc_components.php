<?php

$components =  array (
    array ('moocng' => 'https://example.com/saml2/metadata/') ,
    #array ('askbot' => 'https://example.com/m/group-metadata.xml') ,
);




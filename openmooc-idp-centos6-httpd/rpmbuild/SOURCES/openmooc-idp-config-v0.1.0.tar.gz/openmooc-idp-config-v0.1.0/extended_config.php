<?php

$config['enable.saml20-idp'] = true;
$config['theme.use'] = 'sspopenmooc:openmooc';

$config['metadata.sources'][] = array('type' => 'flatfile', 'directory' => 'metadata/askbot'),
$config['metadata.sources'][] = array('type' => 'flatfile', 'directory' => 'metadata/moocng'),


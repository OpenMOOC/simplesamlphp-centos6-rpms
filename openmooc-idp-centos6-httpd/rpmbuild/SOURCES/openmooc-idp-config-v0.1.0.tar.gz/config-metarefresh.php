<?php

$config = array(

	'sets' => array(

		'askbot' => array(
			'cron'		=> array('metarefresh'),
			'sources'	=> array(
				array(
					'src' => 'https://example.com/m/group-metadata.xml',
					#'validateFingerprint' => '',
				),
			),
			'expireAfter' 		=> 60*60*24*1, // Maximum 1 days cache time.
			'outputDir' 	=> 'metadata/askbot/',
			'outputFormat' => 'flatfile',
		),

		'moocng' => array(
			'cron'		=> array('metarefresh'),
			'sources'	=> array(
				array(
					'src' => 'https://example.com/saml2/metadata/',
					#'validateFingerprint' => '',
				),
			),
			'expireAfter' 		=> 60*60*24*1, // Maximum 1 days cache time.
			'outputDir' 	=> 'metadata/moocng/',
			'outputFormat' => 'flatfile',
		),
	),
);




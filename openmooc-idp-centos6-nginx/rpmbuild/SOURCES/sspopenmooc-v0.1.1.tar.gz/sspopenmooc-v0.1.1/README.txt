Theme of simpleSAMLphp for the OpenMooc project

Code of the new implementation available at https://github.com/OpenMOOC/sspopenmooc.git

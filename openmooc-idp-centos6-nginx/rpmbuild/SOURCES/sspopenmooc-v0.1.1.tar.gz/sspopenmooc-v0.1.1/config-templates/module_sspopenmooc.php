<?php

$config = array(

	'urls' => array (
		'site' => '',
		'login' => '',
		'register' => '',
		'logout' => '',
		'manageusers' => '',
		'newuser' => '',
		'forgotpassword' => '',
		'changepassword' => '',
		'changemail' => '',
		'profile' => '',
		'legal' => '',
		'tos' => '',
		'copyright' => '',
	),

	// Internal file (Ex.  default.css)  or external (Ex. //example.com/css/default.css)
        // (Notice that // will respect the http/https protocol, 
        //  load elements with different protocol than main page produce warnings on some browser)
	'cssfile' => 'default.css',
	'bootstrapfile' => 'bootstrap.css',
	'imgfile' => 'logo.png',
	'title' => 'OpenMooc',
	'slogan' => 'Knowledge for the masses',


);

?>


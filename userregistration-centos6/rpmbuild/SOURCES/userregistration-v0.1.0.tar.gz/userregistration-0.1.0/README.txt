Module based on "selfregister module"  Revision 33.
	* Available in http://code.google.com/p/simplesamlphp-labs/source/browse/#svn/trunk/modules/selfregister
	* Autors: Andreas Solberg and Thomas Graff

Code of the new implementation available at https://github.com/OpenMOOC/userregistration

Features:
 * Self-registration
 * Update account information
 * Change password
 * Reset password

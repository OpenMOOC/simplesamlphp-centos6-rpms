userregistrationApi
===================

Basic API REST of the userregistration module.